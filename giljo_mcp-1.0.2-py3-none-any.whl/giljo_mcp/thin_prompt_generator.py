"""
Thin Client Prompt Generator (Handover 0088, 0315)

REPLACES: OrchestratorPromptGenerator (prompt_generator.py)

KEY DIFFERENCE: Generates ~600 token prompts with MCP tool references (Handover 0315).
Orchestrators fetch context on-demand via MCP tools (context prioritization enabled).

Architecture (Handover 0315):
- User configures priorities (Handover 0313) and depth (Handover 0314)
- Generator creates thin prompt listing available MCP tools by priority
- Orchestrator fetches context on-demand via MCP tool calls
- Context usage stays within 90% budget (automatic succession trigger)

Token Reduction:
- Fat Prompt (v1.0): ~3500 tokens (inline context embedded in prompt)
- Thin Prompt (v2.0): ~600 tokens (MCP tool references only)
- Reduction: ~82% token savings on initial prompt

MCP Tools (Handover 0280-0281 Monolithic Context):
- get_orchestrator_instructions(job_id, tenant_key): Complete mission with prioritized context

Priority System (Handover 0313):
- Priority 1 (CRITICAL): Fetch first, essential for mission planning
- Priority 2 (IMPORTANT): Fetch if budget allows, enhances quality
- Priority 3 (NICE_TO_HAVE): Fetch if extra budget, provides additional context
- Priority 4 (EXCLUDED): Not listed in prompt, ignored by orchestrator

Depth Configuration (Handover 0314):
- vision_documents: "none" | "light" | "medium" | "full"
- memory_last_n_projects: 1 | 3 | 5 | 10
- git_commits: 10 | 25 | 50 | 100
- agent_templates: "type_only" | "full"
- tech_stack_sections: "required" | "all"
- architecture_depth: "overview" | "detailed"

Author: GiljoAI Development Team
Date: 2025-11-02 (Initial), 2025-11-17 (Handover 0315)
Priority: CRITICAL - Enables Commercial Product
"""

import logging
from dataclasses import dataclass
from datetime import datetime
from typing import Any, Dict, Optional
from uuid import uuid4

from sqlalchemy import and_, func, select
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy.orm import joinedload

from src.giljo_mcp.config_manager import get_config
from src.giljo_mcp.models import Product, Project, User
from src.giljo_mcp.models.agent_identity import AgentJob, AgentExecution


logger = logging.getLogger(__name__)


@dataclass
class ThinPromptResponse:
    """Thin client prompt response."""

    prompt: str
    orchestrator_id: str
    project_id: str
    project_name: str
    estimated_prompt_tokens: int
    mcp_tool_name: str
    instructions_stored: bool


class ThinClientPromptGenerator:
    """
    Generates thin client prompts for orchestrators.

    CRITICAL: This enables the context prioritization and orchestration feature.

    Architecture:
    - Prompt contains only identity (~10 lines, 50 tokens)
    - Mission fetched via get_orchestrator_instructions() MCP tool
    - Field priorities applied at fetch time, not embed time

    Workflow:
    1. Create orchestrator job in database
    2. Store basic mission placeholder
    3. Generate thin prompt with orchestrator_id
    4. Return prompt to user
    5. User pastes into Claude Code CLI
    6. Orchestrator calls get_orchestrator_instructions(job_id)
    7. MCP tool generates condensed mission with field priorities (6K tokens)

    Benefits:
    - Professional UX (copy 10 lines, not 3000)
    - context prioritization and orchestration ACTIVE (applied by MCP tool)
    - Dynamic mission updates possible
    - Commercial-grade appearance

    Note: Mission condensation happens in the MCP tool get_orchestrator_instructions(),
    not here. This generator just creates the thin prompt and placeholder job.
    """

    def __init__(self, db: AsyncSession, tenant_key: str):
        """
        Initialize thin client prompt generator.

        Args:
            db: Database session
            tenant_key: Tenant isolation key
        """
        self.db = db
        self.tenant_key = tenant_key

    async def generate(
        self,
        project_id: str,
        user_id: Optional[str] = None,
        tool: str = "universal",
        instance_number: int = 1,
        field_priorities: Optional[Dict[str, int]] = None,
        depth_config: Optional[Dict[str, Any]] = None,  # NEW PARAMETER (Handover 0315)
    ) -> Dict[str, Any]:
        """
        Generate a thin orchestrator prompt for a specified project.

        Handover 0088: Now uses metadata JSONB column instead of handover_summary
        for storing field_priorities, user_id, tool, and other thin client data.

        Handover 0315: Generates thin prompts (~600 tokens) that reference MCP tools
        for on-demand context fetching, replacing fat prompts (~3500 tokens) with
        inline context.

        Args:
            project_id: Project UUID
            user_id: Optional user ID for tracking and fetching priorities/depth config
            tool: AI coding tool (claude-code, codex, gemini, universal)
            instance_number: Orchestrator instance number (for succession)
            field_priorities: Optional field importance weights (v2.0 categories)
            depth_config: Optional depth configuration (v2.0 depth settings)

        Returns:
            Dict with orchestrator_id and thin_prompt
        """
        # Fetch project using tenant_key from instance
        project_stmt = select(Project).where(and_(Project.id == project_id, Project.tenant_key == self.tenant_key))
        project_result = await self.db.execute(project_stmt)
        project = project_result.scalar_one_or_none()

        if not project:
            raise ValueError(f"Project {project_id} not found")

        # Fetch product for context injection
        product = await self._fetch_product(project_id)

        # Handover 0315: Fetch user priorities and depth config if user_id provided
        if user_id and (not field_priorities or not depth_config):
            from src.giljo_mcp.models.auth import User

            user_stmt = select(User).where(and_(User.id == user_id, User.tenant_key == self.tenant_key))
            user_result = await self.db.execute(user_stmt)
            user = user_result.scalar_one_or_none()

            if user:
                # Use user config if not provided
                if not field_priorities and user.field_priority_config:
                    # Extract priorities dict from v2.0 structure
                    field_priorities = user.field_priority_config.get("priorities", {})

                if not depth_config and user.depth_config:
                    depth_config = user.depth_config

        # Apply defaults for depth_config if still not set
        if not depth_config:
            depth_config = {
                "vision_documents": "medium",
                "memory_last_n_projects": 3,
                "git_commits": 25,
                "agent_templates": "type_only",
                "tech_stack_sections": "all",
                "architecture_depth": "overview",
            }

        # Handover 0111 - Issue #2: Check for existing active orchestrator BEFORE creating new one
        # This prevents duplicate orchestrator creation on every "Stage Project" button click
        # Handover 0367c-2: Use AgentExecution only (no fallback to MCPAgentJob)

        # Check for existing active orchestrator (AgentExecution)
        existing_exec_stmt = (
            select(AgentExecution)
            .options(joinedload(AgentExecution.job))  # Eager load for job_metadata access
            .join(AgentJob, AgentExecution.job_id == AgentJob.job_id)
            .where(
                AgentJob.project_id == project_id,
                AgentExecution.agent_type == "orchestrator",
                AgentExecution.tenant_key == self.tenant_key,
                AgentExecution.status.in_(["waiting", "working"]),
            )
            .order_by(AgentExecution.instance_number.desc())
        )

        existing_exec_result = await self.db.execute(existing_exec_stmt)
        existing_execution = existing_exec_result.scalars().first()

        if existing_execution:
            # Reuse existing active orchestrator
            orchestrator_id = existing_execution.job_id
            instance_number = existing_execution.instance_number

            # BUG FIX (Handover 0275): Update job_metadata when reusing orchestrator
            # Handover 0367c-2: Update AgentJob.job_metadata (persistent work order metadata)

            # Update parent AgentJob metadata
            if existing_execution.job:
                existing_execution.job.job_metadata = {
                    "field_priorities": field_priorities or {},
                    "depth_config": depth_config,
                    "user_id": user_id,
                    "tool": tool,
                    "created_via": "thin_client_generator",
                    "reused_at": str(datetime.now()),
                }
                await self.db.commit()

            logger.info(
                f"[ThinPromptGenerator] Reusing existing orchestrator {orchestrator_id} "
                f"(instance #{instance_number}) for project {project_id} - metadata updated"
            )
        else:
            # No active orchestrator exists - create new one
            logger.info(
                f"[ThinPromptGenerator] Creating NEW orchestrator for project {project_id} "
                f"(no active orchestrator found)"
            )

            # Store project mission as placeholder
            # IMPORTANT: The REAL condensed mission (with context prioritization) is generated
            # by the MCP tool get_orchestrator_instructions() when the orchestrator calls it.
            # This placeholder ensures the job exists in the database for MCP lookup.
            placeholder_mission = project.mission or f"Orchestrator mission for project: {project.name}"

            # If instance_number not provided, calculate next in sequence
            # Handover 0367c-2: Check AgentExecution only (no fallback)
            if instance_number is None or instance_number == 1:
                # Check AgentExecution for max instance number
                exec_instance_stmt = (
                    select(func.coalesce(func.max(AgentExecution.instance_number), 0))
                    .join(AgentJob, AgentExecution.job_id == AgentJob.job_id)
                    .where(
                        AgentJob.tenant_key == self.tenant_key,
                        AgentJob.project_id == project_id,
                        AgentExecution.agent_type == "orchestrator",
                    )
                )
                exec_instance_result = await self.db.execute(exec_instance_stmt)
                max_instance = exec_instance_result.scalar() or 0

                instance_number = max_instance + 1

            # Generate orchestrator_id (full UUID for consistency)
            orchestrator_id = str(uuid4())
            agent_id = str(uuid4())

            # Handover 0366: Create dual-model pattern (AgentJob + AgentExecution)
            # Step 1: Create AgentJob (work order - persistent across succession)
            agent_job = AgentJob(
                job_id=orchestrator_id,
                tenant_key=self.tenant_key,
                project_id=project_id,
                mission=placeholder_mission,  # Placeholder - real mission from MCP tool
                job_type="orchestrator",
                status="active",
                job_metadata={
                    "field_priorities": field_priorities or {},
                    "depth_config": depth_config,  # Handover 0315
                    "user_id": user_id,
                    "tool": tool,
                    "created_via": "thin_client_generator",
                },
            )
            self.db.add(agent_job)

            # Step 2: Create AgentExecution (executor instance)
            agent_execution = AgentExecution(
                agent_id=agent_id,
                job_id=orchestrator_id,
                tenant_key=self.tenant_key,
                agent_type="orchestrator",
                agent_name=f"Orchestrator #{instance_number}",
                instance_number=instance_number,
                status="waiting",
                progress=0,
                tool_type=tool,
                context_budget=project.context_budget,
                context_used=0,
                messages=[],
            )
            self.db.add(agent_execution)

            await self.db.commit()
            await self.db.refresh(agent_job)
            await self.db.refresh(agent_execution)

            logger.info(
                f"[ThinPromptGenerator] Created orchestrator {orchestrator_id} " f"(instance #{instance_number})"
            )

        # Handover 0315: Generate thin prompt with MCP tool references (NOT fat prompt)
        thin_prompt = await self._generate_thin_prompt(
            orchestrator_id=orchestrator_id,
            project_id=project_id,
            project=project,
            product=product,
            instance_number=instance_number,
            tool=tool,
            field_priorities=field_priorities or {},
            depth_config=depth_config,
            user_id=user_id,
        )

        # Estimate prompt tokens (rough: 1 token ≈ 4 characters)
        estimated_tokens = len(thin_prompt) // 4

        logger.info(
            f"[ThinPromptGenerator] Generated thin prompt for {orchestrator_id}: "
            f"~{estimated_tokens} tokens (target: 600, reduction from fat: ~{3500 - estimated_tokens})"
        )

        # Handover 0276: Regenerate orchestrator instructions with current settings
        # This enables "Stage Project refresh" - when user changes field priorities
        # and clicks "Stage Project" again, they get updated instructions immediately
        regenerated_mission = await self._regenerate_mission(
            product=product, project=project, field_priorities=field_priorities or {}, user_id=user_id
        )

        # Estimate tokens
        estimated_mission_tokens = len(regenerated_mission) // 4 if regenerated_mission else 0

        if regenerated_mission:
            logger.info(
                f"[ThinPromptGenerator] Regenerated orchestrator instructions for {orchestrator_id}: "
                f"~{estimated_mission_tokens} tokens (reflects current field priorities)"
            )
        else:
            logger.warning(f"[ThinPromptGenerator] Mission regeneration returned empty for {orchestrator_id}")

        return {
            "orchestrator_id": orchestrator_id,
            "thin_prompt": thin_prompt,
            "instance_number": instance_number,
            "context_budget": project.context_budget,
            "estimated_prompt_tokens": estimated_tokens,
            # Handover 0276: Include regenerated mission in response
            "mission": regenerated_mission,
            "estimated_mission_tokens": estimated_mission_tokens,
        }

    async def _regenerate_mission(
        self, product: Product, project: Project, field_priorities: Dict[str, int], user_id: Optional[str]
    ) -> str:
        """
        Regenerate orchestrator mission with current field priorities.

        Handover 0276: Enables "Stage Project refresh" - user changes settings,
        clicks "Stage Project", gets updated instructions immediately.

        This is a simplified version of MissionPlanner._build_context_with_priorities
        that works within the existing transaction (doesn't create new session).

        Args:
            product: Product model with vision and config
            project: Project model with description
            field_priorities: Field importance weights (1-4 scale)
            user_id: User ID for audit trail

        Returns:
            Regenerated mission string with current context
        """
        try:
            mission_parts = []

            # Product description (always include if available)
            if product and product.description:
                mission_parts.append(f"## Product\n{product.description}")

            # Project description
            if project.description:
                mission_parts.append(f"## Project Goal\n{project.description}")

            # Project mission (if exists)
            if project.mission:
                mission_parts.append(f"## Mission\n{project.mission}")

            # Tech stack (from product config_data)
            tech_priority = field_priorities.get("tech_stack", 2)
            if product and product.config_data and tech_priority > 0:
                tech_stack = product.config_data.get("tech_stack", {})
                if tech_stack:
                    tech_parts = []
                    # Handle dict format: {"languages": [...], "frameworks": [...]}
                    if isinstance(tech_stack, dict):
                        if tech_stack.get("languages"):
                            tech_parts.append(f"Languages: {', '.join(tech_stack['languages'])}")
                        if tech_stack.get("frameworks"):
                            tech_parts.append(f"Frameworks: {', '.join(tech_stack['frameworks'])}")
                    # Handle list format: ["Python 3.11+", "PostgreSQL"]
                    elif isinstance(tech_stack, list):
                        tech_parts.append(f"Stack: {', '.join(tech_stack)}")
                    # Handle string format: "Python 3.11+"
                    elif isinstance(tech_stack, str):
                        tech_parts.append(f"Stack: {tech_stack}")
                    if tech_parts:
                        mission_parts.append(f"## Tech Stack\n{chr(10).join(tech_parts)}")

            # Architecture (from product config_data)
            arch_priority = field_priorities.get("architecture", 2)
            if product and product.config_data and arch_priority > 0:
                architecture = product.config_data.get("architecture", {})
                if architecture and architecture.get("patterns"):
                    mission_parts.append(f"## Architecture\n{', '.join(architecture['patterns'])}")

            # Join all parts
            if mission_parts:
                regenerated = "\n\n".join(mission_parts)
                logger.debug(
                    f"[ThinPromptGenerator] Mission regenerated: {len(mission_parts)} sections, "
                    f"{len(regenerated)} chars"
                )
                return regenerated
            # Fallback if no parts available
            logger.warning("[ThinPromptGenerator] No mission parts available for regeneration")
            return project.mission or f"Mission for project: {project.name}"

        except Exception as e:
            logger.exception(f"[ThinPromptGenerator] Failed to regenerate mission: {e}")
            # Return project mission as fallback
            return project.mission or f"Mission for project: {project.name}"

    def _build_thin_prompt(
        self, orchestrator_id: str, project_id: str, project_name: str, instance_number: int, tool: str
    ) -> str:
        """
        Build thin client prompt (~10 lines).

        This is THE critical output - must be concise and professional.

        Includes MCP connection details (Amendment C).
        """
        # Get MCP server configuration
        config = get_config()

        # Use external_host (user-facing IP) not api_host (bind address 0.0.0.0)
        # External host is configured during installation for network access
        # Need to read config.yaml directly as ConfigManager doesn't load services section
        from pathlib import Path

        import yaml

        try:
            config_path = Path("config.yaml")
            if config_path.exists():
                with open(config_path, encoding="utf-8") as f:
                    config_data = yaml.safe_load(f) or {}
                mcp_host = config_data.get("services", {}).get("external_host") or config.server.api_host
            else:
                mcp_host = config.server.api_host
        except Exception:
            # Fallback to api_host if YAML loading fails
            mcp_host = config.server.api_host

        mcp_port = config.server.api_port
        mcp_url = f"http://{mcp_host}:{mcp_port}"

        # Generate API key hint (if configured)
        api_key_configured = bool(config.server.api_key)
        auth_note = "(authenticated)" if api_key_configured else "(check config.yaml for API key)"

        return f"""I am Orchestrator #{instance_number} for GiljoAI Project "{project_name}".

IDENTITY:
- Orchestrator ID: {orchestrator_id}
- Project ID: {project_id}
- Tenant Key: {self.tenant_key}

MCP CONNECTION:
- Server URL: {mcp_url}
- Tool Prefix: mcp__giljo-mcp__
- Auth Status: {auth_note}

YOUR ROLE: PROJECT STAGING (NOT EXECUTION)
You are STAGING the project by creating a mission plan. You will NOT execute the work yourself.
Your job is to: 1) Analyze requirements, 2) Create mission plan, 3) Assign work to specialist agents.

MCP TOOLS AVAILABLE (ALL start with "mcp__giljo-mcp__"):
✓ health_check() - Verify MCP connection
✓ get_orchestrator_instructions(job_id, tenant_key) - Fetch context
✓ update_project_mission(project_id, mission) - Save mission plan
✓ spawn_agent_job(agent_type, agent_name, mission, project_id, tenant_key) - Create agents
✓ get_workflow_status(project_id, tenant_key) - Check spawned agents
✓ send_message(to_agents, content, project_id, message_type, priority) - Send message/broadcast to agents

STARTUP SEQUENCE:
1. Verify MCP: mcp__giljo-mcp__health_check()
2. Fetch context: mcp__giljo-mcp__get_orchestrator_instructions('{orchestrator_id}', '{self.tenant_key}')
   └─► Returns: Project.description (user requirements), Product context, Agent templates
3. CREATE MISSION: Analyze requirements → Generate execution plan (context prioritization and orchestration)
4. PERSIST MISSION: mcp__giljo-mcp__update_project_mission('{project_id}', your_created_mission)
   └─► Saves to Project.mission field for UI display
5. SPAWN AGENTS: mcp__giljo-mcp__spawn_agent_job() to create specialist agent jobs
   └─► Agents will EXECUTE the work (not you)
6. SIGNAL COMPLETE: mcp__giljo-mcp__send_message() to broadcast staging done
   └─► Message: "STAGING_COMPLETE: Mission created, N agents spawned: [list agent names]"
   └─► This enables the Launch Jobs button in UI (required for workflow)

CRITICAL DISTINCTIONS:
- Project.description = User-written requirements (READ THIS for context)
- Project.mission = YOUR OUTPUT (condensed execution plan you CREATE in Step 3)
- Agent jobs = Specialist agents who will DO THE ACTUAL WORK (you coordinate them)

CONNECTION TROUBLESHOOTING:
If MCP fails: Check server running at {mcp_url}/health
Logs: ~/.giljo_mcp/logs/mcp_adapter.log

Begin by verifying MCP connection, then fetch context and CREATE the mission plan.
"""

    async def _generate_thin_prompt(
        self,
        orchestrator_id: str,
        project_id: str,
        project: Any,
        product: Any,
        instance_number: int,
        tool: str,
        field_priorities: Dict[str, int],
        depth_config: Dict[str, Any],
        user_id: Optional[str] = None,
    ) -> str:
        """
        Generate thin prompt listing available MCP tools by priority (Handover 0315).

        Returns ~600 token prompt (vs ~3500 in fat prompt) that references MCP tools
        for on-demand context fetching.

        Args:
            orchestrator_id: Orchestrator job UUID
            project_id: Project UUID
            project: Project model
            product: Product model
            instance_number: Orchestrator instance number
            tool: AI coding tool (claude-code, codex, gemini, universal)
            field_priorities: User field priority configuration (1=CRITICAL, 2=IMPORTANT, 3=NICE_TO_HAVE, 4=EXCLUDED)
            depth_config: User depth configuration (vision_documents, memory_last_n_projects, etc.)

        Returns:
            Thin prompt with MCP tool references grouped by priority
        """
        # Monolithic Context Architecture (Handover 0280-0281)
        # All context fetched via single MCP tool: get_orchestrator_instructions()
        # Priority filtering and depth configuration applied server-side

        # Get MCP server configuration
        config = get_config()

        # Use external_host (user-facing IP) not api_host (bind address 0.0.0.0)
        from pathlib import Path

        import yaml

        try:
            config_path = Path("config.yaml")
            if config_path.exists():
                with open(config_path, encoding="utf-8") as f:
                    config_data = yaml.safe_load(f) or {}
                mcp_host = config_data.get("services", {}).get("external_host") or config.server.api_host
            else:
                mcp_host = config.server.api_host
        except Exception:
            # Fallback to api_host if YAML loading fails
            mcp_host = config.server.api_host

        mcp_port = config.server.api_port
        mcp_url = f"http://{mcp_host}:{mcp_port}"

        # Generate API key hint (if configured)
        api_key_configured = bool(config.server.api_key)
        auth_note = "(authenticated)" if api_key_configured else "(check config.yaml for API key)"

        # Build thin prompt with MCP tool reference (Monolithic Context Architecture)
        prompt = f"""I am Orchestrator #{instance_number} for GiljoAI Project "{project.name}".

IDENTITY:
- Orchestrator ID: {orchestrator_id}
- Project ID: {project_id}
- Tenant Key: {self.tenant_key}

MCP CONNECTION:
- Server URL: {mcp_url}
- Tool Prefix: mcp__giljo-mcp__
- Auth Status: {auth_note}

YOUR ROLE: PROJECT STAGING (NOT EXECUTION)
You are STAGING the project by creating a mission plan. You will NOT execute the work yourself.
Your job is to: 1) Analyze requirements, 2) Create mission plan, 3) Assign work to specialist agents.

PROJECT CONTEXT (Inline - ~200 tokens):
- Name: {project.name}
- Description: {project.description or '(No description provided)'}
- Mission: {project.mission or '(Mission will be created by you)'}

WORKFLOW:
1. Fetch complete context: mcp__giljo-mcp__get_orchestrator_instructions('{orchestrator_id}', '{self.tenant_key}')
   → Returns prioritized context (vision, tech stack, architecture, memory, git history, templates)
   → User priority configuration automatically applied server-side
   → Depth configuration (chunking, commit count, etc.) pre-configured
2. Create condensed mission plan from fetched context
3. Persist mission: mcp__giljo-mcp__update_project_mission('{project_id}', mission, '{self.tenant_key}')
4. Spawn specialist agents: mcp__giljo-mcp__spawn_agent_job(agent_type, agent_name, mission, '{project_id}', '{self.tenant_key}')
5. Monitor: mcp__giljo-mcp__get_workflow_status('{project_id}', '{self.tenant_key}')
6. Signal complete: mcp__giljo-mcp__send_message(to_agents=['all'], content='STAGING_COMPLETE: Mission created, N agents spawned: [list names]', project_id='{project_id}', message_type='broadcast')
   → This broadcast enables the Launch Jobs button in UI (REQUIRED)

Trigger succession if context usage >90%.
Claude Code: Use TodoWrite tool to track workflow progress.

CRITICAL DISTINCTIONS:
- Project.description = User-written requirements (already provided above)
- Project.mission = YOUR OUTPUT (condensed execution plan you CREATE in Step 2)
- Agent jobs = Specialist agents who will DO THE ACTUAL WORK (you coordinate them)

MCP CORE TOOLS (Always Available):
✓ mcp__giljo-mcp__health_check() - Verify MCP connection
✓ mcp__giljo-mcp__get_orchestrator_instructions('{orchestrator_id}', '{self.tenant_key}') - Fetch complete prioritized context
✓ mcp__giljo-mcp__update_project_mission('{project_id}', mission, '{self.tenant_key}') - Save mission plan
✓ mcp__giljo-mcp__spawn_agent_job(agent_type, agent_name, mission, '{project_id}', '{self.tenant_key}') - Create agents
✓ mcp__giljo-mcp__get_workflow_status('{project_id}', '{self.tenant_key}') - Check spawned agents
✓ mcp__giljo-mcp__send_message(to_agents, content, project_id, message_type, priority) - Send message/broadcast to agents

CONNECTION TROUBLESHOOTING:
If MCP fails: Check server running at {mcp_url}/health
Logs: ~/.giljo_mcp/logs/mcp_adapter.log

Begin by verifying MCP connection, then fetch complete context, and CREATE the mission plan.
"""

        return prompt

    def _inject_360_memory(self, product) -> str:
        """
        Inject 360 Memory System context into prompt.

        ALWAYS included in orchestrator prompts to provide cumulative product knowledge.

        Args:
            product: Product model with product_memory JSONB field

        Returns:
            Formatted 360 memory section (always present, even if no history)

        Examples:
            With history:
                ## 360 Memory System
                Product has 5 previous project history entries.
                Review these to inform decisions and avoid past mistakes.

            Without history:
                ## 360 Memory System
                No previous project history yet. You're starting fresh.
        """
        if not product or not product.product_memory:
            return """
## 360 Memory System
No previous project history available. Starting fresh.
"""

        history_entries = product.product_memory.get("sequential_history", [])
        context_data = product.product_memory.get("context", {})
        objectives = context_data.get("objectives", []) if isinstance(context_data, dict) else []

        history_count = len(history_entries)

        # Build memory section
        memory_lines = ["\n## 360 Memory System"]

        if history_count > 0:
            memory_lines.append(f"Product has {history_count} previous project history entries.")
            memory_lines.append("Review these to inform decisions and avoid past mistakes.")
        else:
            memory_lines.append("No previous project history yet. You're starting fresh.")

        # Add objectives if available
        if objectives:
            memory_lines.append("\nProduct Objectives:")
            for obj in objectives[:3]:  # Limit to top 3 objectives
                memory_lines.append(f"- {obj}")

        memory_lines.append("\nAccess via: product_memory.sequential_history and product_memory.context")

        return "\n".join(memory_lines)

    def _inject_git_instructions(self, product) -> str:
        """
        Inject Git integration instructions into prompt (CONDITIONAL).

        Only included when product.product_memory.git_integration.enabled = True.
        Provides git command instructions for agents to run locally using user's credentials.

        Args:
            product: Product model with product_memory JSONB field

        Returns:
            Formatted git integration section (empty string if disabled)

        Examples:
            Git enabled:
                ## Git Integration
                Use git commands for additional context:
                - git log --oneline -20 main
                - git log --since="1 week ago" --pretty=format:"%h - %s (%an, %ar)"

            Git disabled:
                "" (empty string)
        """
        if not product or not product.product_memory:
            return ""

        git_config = product.product_memory.get("git_integration", {})

        # Return empty string if git integration disabled or not configured
        if not git_config.get("enabled", False):
            return ""

        # Extract config with defaults
        commit_limit = git_config.get("commit_limit", 20)
        default_branch = git_config.get("default_branch", "")

        # Build branch reference (only if specified)
        branch_ref = f" {default_branch}" if default_branch else ""

        # Build git instructions section
        git_lines = [
            "\n## Git Integration",
            "Use git commands for additional context:",
            f"- git log --oneline -{commit_limit}{branch_ref}",
            '- git log --since="1 week ago" --pretty=format:"%h - %s (%an, %ar)"',
            "- git show --stat HEAD~5..HEAD",
            "",
            "Combine git history with 360 Memory for full context.",
        ]

        return "\n".join(git_lines)

    async def _fetch_product(self, project_id: str) -> Optional[Any]:
        """
        Fetch product for a given project.

        Args:
            project_id: Project UUID

        Returns:
            Product model or None if not found
        """
        from src.giljo_mcp.models.products import Product
        from src.giljo_mcp.models.projects import Project as ProjectModel

        # Fetch project first
        project_stmt = select(ProjectModel).where(
            and_(ProjectModel.id == project_id, ProjectModel.tenant_key == self.tenant_key)
        )
        project_result = await self.db.execute(project_stmt)
        project = project_result.scalar_one_or_none()

        if not project:
            return None

        # Fetch product via project.product_id
        product_stmt = select(Product).where(
            and_(Product.id == project.product_id, Product.tenant_key == self.tenant_key)
        )
        product_result = await self.db.execute(product_stmt)
        product = product_result.scalar_one_or_none()

        return product

    async def _fetch_project(self, project_id: str) -> Optional[Any]:
        """
        Fetch project by ID.

        Args:
            project_id: Project UUID

        Returns:
            Project model or None if not found
        """
        from src.giljo_mcp.models.projects import Project as ProjectModel

        project_stmt = select(ProjectModel).where(
            and_(ProjectModel.id == project_id, ProjectModel.tenant_key == self.tenant_key)
        )
        project_result = await self.db.execute(project_stmt)
        project = project_result.scalar_one_or_none()

        return project

    def _build_thin_prompt_with_memory(
        self,
        orchestrator_id: str,
        project_id: str,
        project_name: str,
        instance_number: int,
        tool: str,
        product,
        field_priorities: Optional[Dict[str, int]] = None,
    ) -> str:
        """
        Build thin client prompt WITH 360 Memory, Git integration, and Agent templates.

        This extends _build_thin_prompt with context injection.

        Handover 0306: Now includes agent templates based on field priority configuration.

        Args:
            orchestrator_id: Orchestrator job UUID
            project_id: Project UUID
            project_name: Project display name
            instance_number: Orchestrator instance number
            tool: AI coding tool (claude-code, codex, gemini, universal)
            product: Product model for context injection
            field_priorities: Optional user field priority config

        Returns:
            Enhanced thin prompt with memory, git, and agent template sections
        """
        # Get base prompt (existing logic)
        base_prompt = self._build_thin_prompt(
            orchestrator_id=orchestrator_id,
            project_id=project_id,
            project_name=project_name,
            instance_number=instance_number,
            tool=tool,
        )

        # Inject 360 Memory (ALWAYS)
        memory_section = self._inject_360_memory(product)

        # Inject Git integration (CONDITIONAL)
        git_section = self._inject_git_instructions(product)

        # Handover 0306: Inject Agent Templates (CONDITIONAL - based on priority)
        # Handover 0246c: Agent templates no longer embedded (use get_available_agents MCP tool)
        agent_section = ""  # Deprecated: templates fetched via MCP tool

        # Insert injections BEFORE "YOUR ROLE" section
        # This places context EARLY in the prompt for maximum impact
        insertion_marker = "YOUR ROLE: PROJECT STAGING"

        if insertion_marker in base_prompt:
            # Split at marker and insert context
            before_role, after_role = base_prompt.split(insertion_marker, 1)
            enhanced_prompt = (
                before_role + memory_section + git_section + agent_section + "\n" + insertion_marker + after_role
            )
        else:
            # Fallback: append at end if marker not found
            enhanced_prompt = base_prompt + memory_section + git_section + agent_section

        return enhanced_prompt

    async def _get_user_field_priorities(self, user_id: str) -> Dict[str, int]:
        """
        Fetch user's field priority configuration.

        Returns dict like:
            {
                'product_vision': 10,  # Full detail
                'architecture': 7,      # Moderate
                'tech_stack': 8,        # Moderate-high
                'dependencies': 2       # Minimal
            }
        """
        # Get user config from database
        result = await self.db.execute(select(User).where(User.id == user_id, User.tenant_key == self.tenant_key))
        user = result.scalar_one_or_none()

        if not user or not user.field_priority_config:
            return {}

        return user.field_priority_config

    async def generate_execution_prompt(
        self, orchestrator_job_id: str, project_id: str, claude_code_mode: bool = False
    ) -> str:
        """
        DEPRECATED: Use generate_staging_prompt() instead (universal Scenario B).

        This method is kept for backward compatibility only.
        Will be removed in v4.0.
        """
        logger.warning(
            "[ThinPromptGenerator] generate_execution_prompt() is deprecated. "
            "Use generate_staging_prompt() for universal prompt generation.",
            extra={
                "method_called": "generate_execution_prompt",
                "recommended_method": "generate_staging_prompt",
                "orchestrator_job_id": orchestrator_job_id,
                "project_id": project_id,
                "tenant_key": self.tenant_key,
            },
        )

        # Redirect to universal prompt generator
        return await self.generate_staging_prompt(
            orchestrator_id=orchestrator_job_id, project_id=project_id, claude_code_mode=claude_code_mode
        )

    def _get_external_host(self) -> str:
        """
        Get external MCP server host from config.

        Returns external_host for user-facing connections,
        falls back to api_host if not configured.
        """
        from pathlib import Path

        import yaml

        try:
            config_path = Path("config.yaml")
            if config_path.exists():
                with open(config_path, encoding="utf-8") as f:
                    config_data = yaml.safe_load(f) or {}
                external_host = config_data.get("services", {}).get("external_host")
                if external_host:
                    return external_host
        except Exception:
            pass

        # Fallback to api_host from config
        config = get_config()
        return config.server.api_host

    async def generate_staging_prompt(
        self, orchestrator_id: str, project_id: str, claude_code_mode: bool = False
    ) -> str:
        """
        Generate simple orchestrator staging prompt (Handover 0333).

        Restores the working pattern from commit 051addde with mode awareness.
        Replaces the broken 7-task workflow with a simple ~50 line prompt.

        Args:
            orchestrator_id: Orchestrator job UUID
            project_id: Project UUID
            claude_code_mode: Use Claude Code CLI mode (default: False)

        Returns:
            Simple staging prompt (~50-60 lines)

        Raises:
            ValueError: If project or product not found
        """
        project = await self._fetch_project(project_id)
        product = await self._fetch_product(project_id)

        if not project or not product:
            raise ValueError(f"Project {project_id} or its product not found")

        # Get MCP server URL
        config = get_config()
        mcp_host = self._get_external_host()
        mcp_port = config.server.api_port
        mcp_url = f"http://{mcp_host}:{mcp_port}"

        execution_mode = "Claude Code CLI" if claude_code_mode else "Multi-Terminal"

        # Mode-specific instructions
        if claude_code_mode:
            # Handover 0342: Trimmed CLI mode block - verbose version in get_orchestrator_instructions()
            mode_block = """CLI MODE CRITICAL:
This project uses Claude Code CLI for implementation. When spawning agents:
- agent_name: SINGLE SOURCE OF TRUTH - must EXACTLY match template name (e.g., "implementer-frontend")
- agent_type: Display category label (e.g., "implementer")
- Template file: Each agent_name requires .claude/agents/{agent_name}.md

Example Task call:
  Task(subagent_type="{agent_name}", instructions="...")

In implementation phase, Task(subagent_type=X) uses agent_name value, NOT agent_type.
Full cli_mode_rules, allowed_agent_names, and examples are in get_orchestrator_instructions() response."""
        else:
            mode_block = """MULTI-TERMINAL MODE:
- User will manually copy/paste prompts for each agent
- Each agent has [Copy Prompt] button in the Implementation tab
- Coordinate agents via MCP messaging tools"""

        prompt = f"""I am Orchestrator for GiljoAI Project "{project.name}".

IDENTITY:
- Orchestrator ID: {orchestrator_id}
- Project ID: {project_id}
- Tenant Key: {self.tenant_key}
- Execution Mode: {execution_mode}

MCP CONNECTION:
- Server URL: {mcp_url}
- Tool Prefix: mcp__giljo-mcp__

YOUR ROLE: PROJECT STAGING (NOT EXECUTION)
You are STAGING the project. Your job:
1) Analyze requirements
2) Create mission plan
3) Assign work to specialist agents

STARTUP SEQUENCE:
1. Verify MCP: health_check()
2. Fetch context: get_orchestrator_instructions(job_id='{orchestrator_id}', tenant_key='{self.tenant_key}')
   Returns: Project description, Product context, AVAILABLE AGENT TEMPLATES
3. CREATE MISSION: Analyze requirements and generate execution plan
4. PERSIST MISSION: update_project_mission('{project_id}', your_mission)
5. SPAWN AGENTS: spawn_agent_job() for each specialist
   CRITICAL: agent_name MUST exactly match template name from Step 2
   agent_type can be descriptive category (for UI display only)
6. SIGNAL COMPLETE: send_message(to_agents=['all'], content='STAGING_COMPLETE: Mission created, N agents spawned', project_id='{project_id}', message_type='broadcast')
   This broadcast enables the Launch Jobs button in UI (REQUIRED)
7. EXECUTION PHASE MONITORING: After spawning agents, enter monitoring mode:

   **Sequential Pattern**: Spawn agent → Poll via `receive_messages()` → Wait for completion → Send handoff message → Spawn next agent

   **Parallel Pattern**: Spawn all agents → Poll ALL via `receive_messages()` every 2-3 minutes → Coordinate as agents finish

   **MANDATORY**: Before calling `complete_job()`, you MUST call `receive_messages()` to process any blocking issues or agent error reports.

{mode_block}

Begin by calling health_check(), then get_orchestrator_instructions().
"""

        return prompt

    def _build_multi_terminal_execution_prompt(self, orchestrator_id: str, project, agent_jobs: list) -> str:
        """
        Build multi-terminal mode execution prompt.

        User manually launches agents in separate terminals.
        Orchestrator coordinates their work via MCP.

        Handover 0247 Gap 3: Added Product ID to identity section.
        """
        # Format agent list
        agent_list_lines = []
        if agent_jobs:
            for agent in agent_jobs:
                agent_list_lines.append(f"- {agent.agent_name} (Agent ID: {agent.job_id})")
        else:
            agent_list_lines.append("(No agents spawned yet)")

        agent_list = "\n".join(agent_list_lines)

        return f"""PROJECT EXECUTION PHASE - MULTI-TERMINAL MODE

Orchestrator ID: {orchestrator_id}
Project ID: {project.id}
Product ID: {project.product_id}
Project: {project.name}
Tenant Key: {self.tenant_key}

CONTEXT:
- Project mission created and persisted
- Specialist agents spawned and waiting
- User launching agents in separate terminal windows

YOUR ROLE: COORDINATE AGENT WORKFLOW
1. Monitor dashboard for agent progress updates
2. Respond to agent messages via MCP
3. Track completion status
4. Handle blockers and escalations

IMPORTANT:
- Agents check in via acknowledge_job()
- You coordinate, agents execute
- User manually manages terminal windows

AGENT TEAM:
{agent_list}

Monitor workflow via: mcp__giljo-mcp__get_workflow_status('{project.id}', '{self.tenant_key}')
"""

    def _build_claude_code_execution_prompt(self, orchestrator_id: str, project, agent_jobs: list) -> str:
        """
        Build Claude Code subagent mode execution prompt.

        Orchestrator spawns sub-agents using Task tool.
        Sub-agents receive identity via instructions string.

        Handover 0247 Gap 3: Added Product ID to identity section.
        Handover 0337 Task 3: Complete 7-section implementation prompt.
        """
        # SECTION 1: Context Recap
        context_recap = [
            "# GiljoAI Implementation Phase - Claude Code CLI Mode",
            "",
            "## Who You Are",
            f"You are Orchestrator (job_id: {orchestrator_id}) for project '{project.name}'",
            f"Tenant: {self.tenant_key}",
            f"Project ID: {project.id}",
            f"Product ID: {project.product_id}",
            "",
            "## What You've Already Done",
            "In a PREVIOUS session, you completed staging:",
            "- Analyzed project requirements",
            "- Created mission plan",
            f"- Spawned {len(agent_jobs) if agent_jobs else 0} specialist agents",
            "",
            "## Current State",
            "All agent jobs are in waiting status, ready for execution.",
            "Your job now: Spawn and coordinate these agents to complete the project.",
            "---",
            "",
        ]

        # SECTION 2: Agent Jobs List (with CRITICAL agent_type field)
        agent_spawn_lines = []
        if agent_jobs:
            for idx, agent in enumerate(agent_jobs, 1):
                mission = agent.mission or "(No mission assigned)"
                # Truncate long missions
                mission_summary = mission[:100] + "..." if len(mission) > 100 else mission

                agent_spawn_lines.extend(
                    [
                        f"**{idx}. {agent.agent_name}**",
                        f"   - Agent Name: `{agent.agent_name}` (matches .claude/agents/{agent.agent_name}.md)",
                        f"   - Agent Type: `{agent.agent_type}` (display category)",
                        f"   - Job ID: `{agent.job_id}`",
                        f"   - Status: {agent.status}",
                        f"   - Mission Summary: {mission_summary}",
                        "",
                    ]
                )
        else:
            agent_spawn_lines.append("(No agents spawned yet - use spawn_agent_job() first)")

        agent_list_section = [
            "## Agent Jobs to Execute",
            "",
            "Below are the specialist agents spawned during staging.",
            "Each has a unique job_id and agent_type.",
            "",
        ] + agent_spawn_lines

        # SECTION 3: Task Tool Spawning Template
        spawning_section = [
            "## How to Spawn Agents via Task Tool",
            "",
            "### Spawning Template",
            "Use this exact syntax to spawn each agent in parallel:",
            "",
            "```python",
            "Task(",
            '    subagent_type="{agent_name}",  # CRITICAL: Use agent_name (template filename)',
            '    instructions="""',
            "    You are {agent_name} (job_id: {job_id})",
            "    Tenant: {tenant_key}",
            "    ",
            '    First action: Call mcp__giljo-mcp__get_agent_mission as a tool',
            '    with agent_job_id="{job_id}" and tenant_key="{tenant_key}".',
            "    This returns your `mission` and `full_protocol`.",
            "    Follow `full_protocol` for all lifecycle behavior",
            "    (startup, planning, progress, messaging, completion, error handling).",
            '    """',
            ")",
            "```",
            "",
        ]

        # Add concrete example if agents exist
        if agent_jobs:
            first = agent_jobs[0]
            spawning_section.extend(
                [
                    "### Example: First Agent",
                    "```python",
                    "Task(",
                    f'    subagent_type="{first.agent_name}",',
                    '    instructions="""',
                    f"    You are {first.agent_name} (job_id: {first.job_id})",
                    f"    Tenant: {self.tenant_key}",
                    "    ",
                    f'    First action: Call mcp__giljo-mcp__get_agent_mission as a tool',
                    f'    with agent_job_id="{first.job_id}" and tenant_key="{self.tenant_key}".',
                    "    This returns your `mission` and `full_protocol`.",
                    "    Follow `full_protocol` for all lifecycle behavior",
                    "    (startup, planning, progress, messaging, completion, error handling).",
                    '    """',
                    ")",
                    "```",
                    "",
                    "### Spawning Strategy",
                    "**CRITICAL**: NEVER use `run_in_background=true` - agents must run in foreground for observability.",
                    "",
                    "Choose spawning approach based on job requirements:",
                    "- **Sequential**: Spawn one agent, wait for completion, then next (best for dependent tasks)",
                    "- **Parallel**: Multiple Task() calls in single message (best for independent tasks)",
                    "",
                    "Each agent runs independently and coordinates via MCP server.",
                    "",
                ]
            )

        # SECTION 4: Monitoring Instructions (Enhanced)
        monitoring_section = [
            "## Monitoring Agent Progress",
            "",
            "### get_workflow_status()",
            "Check all agent statuses:",
            "```python",
            f'get_workflow_status(project_id="{project.id}", tenant_key="{self.tenant_key}")',
            "```",
            "",
            "Returns:",
            "```json",
            "{",
            '  "agents": [',
            '    {"job_id": "...", "status": "working", "progress": 45},',
            '    {"job_id": "...", "status": "blocked", "block_reason": "..."}',
            "  ]",
            "}",
            "```",
            "",
            "### Handle Blockers",
            "- When agent status is 'blocked', read their messages",
            "- Respond via send_message() with instructions",
            "- Update their next_instruction field if needed",
            "",
            "### Message Handling",
            "- Agents report progress via report_progress() and send_message()",
            "- Monitor messages for questions or blockers",
            "- Respond promptly to keep workflow moving",
            "",
        ]

        # SECTION 5: Context Refresh Capability
        context_refresh_section = [
            "## Refreshing Your Context",
            "",
            "If you need to re-read your orchestrator mission:",
            "```python",
            f'get_orchestrator_instructions(job_id="{orchestrator_id}", tenant_key="{self.tenant_key}")',
            "```",
            "",
            "This MCP tool fetches your original staging mission and context.",
            "Use this if you lose track of project objectives or need to verify requirements.",
            "",
        ]

        # SECTION 6: CLI Mode Constraints (CRITICAL)
        cli_constraints_section = [
            "## CLI Mode Constraints",
            "",
            "**WARNING: Agent Template Files Required**",
            "- Each agent_name needs a file: `.claude/agents/{agent_name}.md`",
            '- If file is missing: "Subagent type not found" error',
            '- Example: agent_name="implementer-frontend" requires `.claude/agents/implementer-frontend.md`',
            "",
            "**WARNING: Exact Naming Required**",
            "- Task tool parameter `subagent_type` expects `agent_name`, NOT `agent_type`",
            '- agent_name: Template filename (e.g., "implementer-frontend")',
            '- agent_type: Display category (e.g., "implementer")',
            '- Using agent_type will fail with "Subagent type not found"',
            "",
            "**WARNING: MCP Communication Only**",
            "- All agents run in THIS terminal (Claude Code CLI mode)",
            "- Coordination happens via MCP server (not direct communication)",
            "- All MCP tools require tenant_key for multi-tenant isolation",
            "",
        ]

        # SECTION 7: Completion Instructions
        completion_section = [
            "## When You're Done",
            "",
            "### Verify Sub-Agents Completed",
            "1. Check all agents via get_workflow_status()",
            "2. Ensure all have status='complete' (no failures or blockers)",
            "3. Review final deliverables",
            "",
            "### Complete Your Orchestrator Job",
            "When all sub-agents are done and project is complete:",
            "```python",
            f'complete_job(job_id="{orchestrator_id}", tenant_key="{self.tenant_key}")',
            "```",
            "",
            "### Handover (if needed)",
            "If you reach context limits before completion:",
            "- Use `/gil_handover` slash command to trigger succession",
            "- Or call orchestrator succession MCP tool",
            "- A new orchestrator will continue from where you left off",
            "",
        ]

        # Combine all sections
        all_sections = (
            context_recap
            + agent_list_section
            + spawning_section
            + monitoring_section
            + context_refresh_section
            + cli_constraints_section
            + completion_section
        )

        return "\n".join(all_sections)

    def _get_field_priority(self, field_name: str, user_priorities: Optional[dict]) -> Optional[int]:
        """
        Get priority for a specific field from user config or defaults.

        Args:
            field_name: Field name (e.g., "agent_templates")
            user_priorities: User's custom field priority config (optional)

        Returns:
            Priority level (1-3) or None if unassigned

        Example:
            >>> priority = self._get_field_priority("agent_templates", {"agent_templates": 2})
            >>> print(priority)
            2
        """
        from src.giljo_mcp.config.defaults import DEFAULT_FIELD_PRIORITY

        # Check user custom priorities first
        if user_priorities and field_name in user_priorities:
            return user_priorities[field_name]

        # Fall back to default priorities
        default_fields = DEFAULT_FIELD_PRIORITY.get("fields", {})
        return default_fields.get(field_name)
